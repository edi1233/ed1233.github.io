# px-pdns Helm Chart

This chart deploys:
- PowerDNS Authoritative (`auth`)
- PowerDNS Recursor (`recursor`)
- dnsdist (`dnsdist`)
- PowerDNS-Admin (`pda`)
- MariaDB (`db`)

## Install

```bash
helm upgrade --install px-pdns ./helm/px-pdns -n pdns --create-namespace \
  --set secrets.create=true \
  --set secrets.data.pdns-api-key=<api-key> \
  --set secrets.data.pda-secret-key=<secret> \
  --set secrets.data.MYSQL_ROOT_PASSWORD=<root-pass> \
  --set secrets.data.MYSQL_PASSWORD=<db-pass>
```

If you already manage secrets externally, set `secrets.existingSecret=<your-secret>` (and keep `secrets.create=false`).


### Existing secret option

You can reuse an existing secret by setting:

```bash
--set secrets.existingSecret=pdns-secrets
--set secrets.create=false
```

When `secrets.existingSecret` is set, the chart will not create a secret and all workloads reference that existing secret.

## External MariaDB Galera option

To use an external MariaDB Galera cluster:

1. Disable in-chart DB and enable external DB settings.
2. Use chart-managed secret (`secrets.create=true`) or provide your own secret with key `pda-sqlalchemy-database-uri`.

Example:

```bash
helm upgrade --install px-pdns ./helm/px-pdns -n pdns --create-namespace \
  --set db.enabled=false \
  --set externalDatabase.enabled=true \
  --set externalDatabase.host=galera-mariadb.mydomain.svc.cluster.local \
  --set externalDatabase.port=3306 \
  --set externalDatabase.database=pdns \
  --set externalDatabase.user=pdnsadmin \
  --set externalDatabase.password='<db-pass>' \
  --set secrets.create=true \
  --set secrets.data.pda-secret-key='<secret>' \
  --set secrets.data.pdns-api-key='<api-key>'
```

If `secrets.create=false` (or `secrets.existingSecret` is set), your external secret must contain:
- `pdns-api-key`
- `pda-secret-key`
- `pda-sqlalchemy-database-uri`
- `MYSQL_ROOT_PASSWORD` (if using in-chart db)
- `MYSQL_DATABASE` (if using in-chart db)
- `MYSQL_USER` (if using in-chart db)
- `MYSQL_PASSWORD` (if using in-chart db)

## Scale options

HPAs and PDBs are enabled by default for `auth`, `recursor`, and `dnsdist`.
Tune these values:
- `auth.hpa.*`
- `recursor.hpa.*`
- `dnsdist.hpa.*`
- `*.replicaCount`

## Notes

- HPA requires metrics-server in the cluster.
- `db` is single replica by default (stateful). Use an external HA database if you need DB-level high availability.
