{{/*
Return chart name
*/}}
{{- define "px-pdns.name" -}}
{{- default .Chart.Name .Values.nameOverride | trunc 63 | trimSuffix "-" -}}
{{- end -}}

{{/*
Return full resource name
*/}}
{{- define "px-pdns.fullname" -}}
{{- if .Values.fullnameOverride -}}
{{- .Values.fullnameOverride | trunc 63 | trimSuffix "-" -}}
{{- else -}}
{{- printf "%s" (include "px-pdns.name" .) | trunc 63 | trimSuffix "-" -}}
{{- end -}}
{{- end -}}

{{/*
Common labels
*/}}
{{- define "px-pdns.labels" -}}
app.kubernetes.io/name: {{ include "px-pdns.name" . }}
app.kubernetes.io/instance: {{ .Release.Name }}
{{- end -}}

{{/*
Return the main secret name used by the chart
Allow override from values.yaml
*/}}
{{- define "px-pdns.secretName" -}}
{{- if .Values.secretName }}
{{- .Values.secretName -}}
{{- else -}}
{{ printf "%s-secrets" (include "px-pdns.fullname" .) }}
{{- end -}}
{{- end -}}

{{/*
Resolve database host
*/}}
{{- define "px-pdns.databaseHost" -}}
{{- if and .Values.externalDatabase .Values.externalDatabase.enabled }}
{{ .Values.externalDatabase.host }}
{{- else }}
{{ printf "%s-db" (include "px-pdns.fullname" .) }}
{{- end }}
{{- end -}}

{{/*
Resolve database port
*/}}
{{- define "px-pdns.databasePort" -}}
{{- if and .Values.externalDatabase .Values.externalDatabase.port }}
{{ .Values.externalDatabase.port }}
{{- else }}
3306
{{- end }}
{{- end -}}
