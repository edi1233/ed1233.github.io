{{/*
Return chart name
*/}}
{{- define "px-pdns.name" -}}
{{- default .Chart.Name .Values.nameOverride | trunc 63 | trimSuffix "-" -}}
{{- end -}}

{{/*
Return full resource name
*/}}
{{- define "px-pdns.fullname" -}}
{{- if .Values.fullnameOverride -}}
{{- .Values.fullnameOverride | trunc 63 | trimSuffix "-" -}}
{{- else -}}
{{- printf "%s" (include "px-pdns.name" .) | trunc 63 | trimSuffix "-" -}}
{{- end -}}
{{- end -}}

{{/*
Common labels
*/}}
{{- define "px-pdns.labels" -}}
app.kubernetes.io/name: {{ include "px-pdns.name" . }}
app.kubernetes.io/instance: {{ .Release.Name }}
{{- end -}}

{{/*
Return the main secret name used by the chart
Allow override from values.yaml
*/}}
{{- define "px-pdns.secretName" -}}
{{- if .Values.px-pdns.secretName }}
{{- .Values.px-pdns.secretName -}}
{{- else -}}
{{ printf "%s-secrets" (include "px-pdns.fullname" .) }}
{{- end -}}
{{- end -}}

{{/*
Resolve database host
*/}}
{{- define "px-pdns.databaseHost" -}}
{{- if .Values.externalDatabase.enabled -}}
{{- required "externalDatabase.host is required when externalDatabase.enabled=true" .Values.externalDatabase.host -}}
{{- else -}}
{{- default (printf "%s-db" (include "px-pdns.fullname" .)) .Values.db.serviceName -}}
{{- end -}}
{{- end -}}

{{/*
Resolve database port
*/}}
{{- define "px-pdns.databasePort" -}}
{{- default 3306 .Values.externalDatabase.port -}}
{{- end -}}
