{{- define "px-pdns.name" -}}
{{- default .Chart.Name .Values.nameOverride | trunc 63 | trimSuffix "-" -}}
{{- end -}}

{{- define "px-pdns.fullname" -}}
{{- if .Values.fullnameOverride -}}
{{- .Values.fullnameOverride | trunc 63 | trimSuffix "-" -}}
{{- else -}}
{{- printf "%s" (include "px-pdns.name" .) | trunc 63 | trimSuffix "-" -}}
{{- end -}}
{{- end -}}

{{- define "px-pdns.labels" -}}
app.kubernetes.io/name: {{ include "px-pdns.name" . }}
app.kubernetes.io/instance: {{ .Release.Name }}
{{- end -}}

{{- define "px-pdns.secretName" -}}
{{- if .Values.secrets.existingSecret -}}
{{- .Values.secrets.existingSecret -}}
{{- else -}}
{{- .Values.secrets.name -}}
{{- end -}}
{{- end -}}

{{- define "px-pdns.databaseHost" -}}
{{- if .Values.externalDatabase.enabled -}}
{{- required "externalDatabase.host is required when externalDatabase.enabled=true" .Values.externalDatabase.host -}}
{{- else -}}
{{- default (printf "%s-db" (include "px-pdns.fullname" .)) .Values.db.serviceName -}}
{{- end -}}
{{- end -}}

{{- define "px-pdns.externalDatabasePassword" -}}
{{- if .Values.externalDatabase.passwordFromSecret.name -}}
{{- printf "$(DB_PASSWORD)" -}}
{{- else -}}
{{- .Values.externalDatabase.password -}}
{{- end -}}
{{- end -}}

{{- define "px-pdns.databaseUri" -}}
{{- if .Values.pda.databaseUri -}}
{{- .Values.pda.databaseUri -}}
{{- else -}}

{{- $dbName := ternary .Values.externalDatabase.database .Values.secrets.data.MYSQL_DATABASE .Values.externalDatabase.enabled -}}
{{- $dbUser := ternary .Values.externalDatabase.user .Values.secrets.data.MYSQL_USER .Values.externalDatabase.enabled -}}
{{- $dbHost := include "px-pdns.databaseHost" . -}}
{{- $dbPort := ternary .Values.externalDatabase.port 3306 .Values.externalDatabase.enabled -}}

{{- if .Values.externalDatabase.passwordFromSecret.name -}}
{{ printf "mysql://%s:$(DB_PASSWORD)@%s:%v/%s" $dbUser $dbHost $dbPort $dbName }}
{{- else -}}
{{- $dbPass := ternary .Values.externalDatabase.password .Values.secrets.data.MYSQL_PASSWORD .Values.externalDatabase.enabled -}}
{{ printf "mysql://%s:%s@%s:%v/%s" $dbUser $dbPass $dbHost $dbPort $dbName }}
{{- end -}}

{{- end -}}
{{- end -}}
